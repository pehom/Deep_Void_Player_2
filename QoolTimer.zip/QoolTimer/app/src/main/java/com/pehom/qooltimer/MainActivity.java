package com.pehom.qooltimer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    ConstraintLayout layout;
    SeekBar seekBar;
    Button button;
    boolean buttonFlag = true;
    int t = 20;
    int min = 0;
    int sec = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.alarm);
        layout = findViewById(R.id.layout);
        seekBar = findViewById(R.id.seekBar);
        seekBar.setMax(1200);
        seekBar.setProgress(t);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                t = progress;
                min = t/60;
                sec = t - min * 60;

                if (min < 10) {
                    if (sec > 9) textView.setText("0" + min + ":" + sec);
                    else textView.setText("0" + min + ":0" + sec);
                }
                else {
                    if (sec > 9) textView.setText("" + min + ":" + sec);
                    else textView.setText("" + min + ":0" + sec);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        textView = findViewById(R.id.textView);
        button = findViewById(R.id.button);
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {

                if (buttonFlag == false && t > 0) {
                        t = t - 1;
                        seekBar.setProgress(t);
                        handler.postDelayed(this, 1000);
                    }
                if (t < 1){
                    buttonFlag = true;
                 //   textView.setText("00:00");
                    mediaPlayer.start();
                    layout.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            mediaPlayer.pause();
                            mediaPlayer.seekTo(0);
                            button.setText("START");
                           // button.setEnabled(true);
                            return false;
                        }
                    });

                }
            }
        };

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch ((String)button.getText()) {
                    case ("START"):
                        buttonFlag = false;
                        button.setText("STOP");
                            if (t == 0) t = 20;
                        handler.post(runnable);
                        break;

                    case ("STOP"):
                        buttonFlag = true;
                        if (mediaPlayer.isPlaying()) {
                            mediaPlayer.pause();
                            mediaPlayer.seekTo(0);
                        }
                        button.setText("START");
                        break;
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater =  getMenuInflater();
        menuInflater.inflate(R.menu.timer_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent settingsIntent = new Intent(this,  SettingsActivity.class);
            startActivity(settingsIntent);
        }
        else {
            Intent aboutIntent = new Intent(this,  AboutActivity.class);
            startActivity(aboutIntent);
        }
        return true;
    }

}
